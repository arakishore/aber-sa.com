
$(function() {
    $( ".datepicker" ).datepicker({
        todayHighlight: true,
        autoclose: true,
    });
});
